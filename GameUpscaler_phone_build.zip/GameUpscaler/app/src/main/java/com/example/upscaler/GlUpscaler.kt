package com.example.upscaler

import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * Captures the screen (via MediaProjection) at `scale` of the output size,
 * then draws it to the overlay surface with Catmull-Rom upscaling + sharpening.
 * Everything runs on one dedicated GL thread.
 */
class GlUpscaler(
    private val projection: MediaProjection,
    private val dpi: Int,
    private val scale: Float,
    private val sharp: Float
) {
    private val thread = HandlerThread("upscaler", Process.THREAD_PRIORITY_URGENT_DISPLAY).apply { start() }
    private val handler = Handler(thread.looper)

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var cfg: EGLConfig? = null
    private var pbuf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var win: EGLSurface = EGL14.EGL_NO_SURFACE

    private var prog = 0
    private var tex = 0
    private var st: SurfaceTexture? = null
    private var capSurface: Surface? = null
    private var vd: VirtualDisplay? = null
    private var capW = 0
    private var capH = 0
    private val texMat = FloatArray(16)

    private var aPos = 0; private var aUV = 0
    private var uTex = 0; private var uMat = 0; private var uSize = 0; private var uPx = 0; private var uSharp = 0

    private val quad: FloatBuffer = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))
            position(0)
        }

    fun start() { handler.post { initGl() } }

    fun setOutput(surface: Surface, w: Int, h: Int) {
        handler.post {
            if (st == null) return@post
            if (win != EGL14.EGL_NO_SURFACE) {
                EGL14.eglMakeCurrent(dpy, pbuf, pbuf, ctx)
                EGL14.eglDestroySurface(dpy, win)
            }
            win = EGL14.eglCreateWindowSurface(dpy, cfg, surface, intArrayOf(EGL14.EGL_NONE), 0)
            EGL14.eglMakeCurrent(dpy, win, win, ctx)
            EGL14.eglSwapInterval(dpy, 0)
            ensureCapture(w, h)
        }
    }

    fun clearOutput() {
        handler.post {
            if (win != EGL14.EGL_NO_SURFACE) {
                EGL14.eglMakeCurrent(dpy, pbuf, pbuf, ctx)
                EGL14.eglDestroySurface(dpy, win)
                win = EGL14.EGL_NO_SURFACE
            }
        }
    }

    fun release() {
        handler.post {
            vd?.release(); vd = null
            capSurface?.release(); capSurface = null
            st?.setOnFrameAvailableListener(null)
            st?.release(); st = null
            if (dpy != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (win != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, win)
                if (pbuf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, pbuf)
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
                EGL14.eglTerminate(dpy)
            }
            dpy = EGL14.EGL_NO_DISPLAY
            thread.quitSafely()
        }
    }

    // ---------------------------------------------------------------- internals

    private fun initGl() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        EGL14.eglInitialize(dpy, ver, 0, ver, 1)
        val attr = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT or EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attr, 0, cfgs, 0, 1, n, 0)
        cfg = cfgs[0]
        ctx = EGL14.eglCreateContext(
            dpy, cfg, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        pbuf = EGL14.eglCreatePbufferSurface(
            dpy, cfg, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
        )
        EGL14.eglMakeCurrent(dpy, pbuf, pbuf, ctx)

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        tex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        prog = buildProgram(VERT, FRAG)
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aUV = GLES20.glGetAttribLocation(prog, "aUV")
        uTex = GLES20.glGetUniformLocation(prog, "uTex")
        uMat = GLES20.glGetUniformLocation(prog, "uTexMatrix")
        uSize = GLES20.glGetUniformLocation(prog, "uTexSize")
        uPx = GLES20.glGetUniformLocation(prog, "uPx")
        uSharp = GLES20.glGetUniformLocation(prog, "uSharp")

        val s = SurfaceTexture(tex)
        s.setOnFrameAvailableListener({ drawFrame() }, handler)
        st = s
    }

    private fun ensureCapture(outW: Int, outH: Int) {
        val s = st ?: return
        val cw = ((outW * scale).toInt() and 1.inv()).coerceAtLeast(2)
        val ch = ((outH * scale).toInt() and 1.inv()).coerceAtLeast(2)
        if (vd != null && cw == capW && ch == capH) return
        capW = cw; capH = ch
        s.setDefaultBufferSize(cw, ch)
        if (vd == null) {
            val surf = Surface(s)
            capSurface = surf
            // Android 14+: createVirtualDisplay may be called only once per projection.
            vd = projection.createVirtualDisplay(
                "upscaler", cw, ch, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surf, null, null
            )
        } else {
            vd?.resize(cw, ch, dpi)
        }
    }

    private fun drawFrame() {
        val s = st ?: return
        val target = if (win != EGL14.EGL_NO_SURFACE) win else pbuf
        if (!EGL14.eglMakeCurrent(dpy, target, target, ctx)) return
        try {
            s.updateTexImage()
            s.getTransformMatrix(texMat)
        } catch (e: Exception) { return }
        if (win == EGL14.EGL_NO_SURFACE) return

        val d = IntArray(1)
        EGL14.eglQuerySurface(dpy, win, EGL14.EGL_WIDTH, d, 0); val w = d[0]
        EGL14.eglQuerySurface(dpy, win, EGL14.EGL_HEIGHT, d, 0); val h = d[0]
        if (w <= 0 || h <= 0) return

        GLES20.glViewport(0, 0, w, h)
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniformMatrix4fv(uMat, 1, false, texMat, 0)
        GLES20.glUniform2f(uSize, capW.toFloat(), capH.toFloat())
        GLES20.glUniform2f(uPx, 1f / capW.coerceAtLeast(1), 1f / capH.coerceAtLeast(1))
        GLES20.glUniform1f(uSharp, sharp)

        quad.position(0)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(aPos)
        quad.position(2)
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(aUV)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        EGL14.eglSwapBuffers(dpy, win)
    }

    private fun buildProgram(vs: String, fs: String): Int {
        fun compile(type: Int, src: String): Int {
            val id = GLES20.glCreateShader(type)
            GLES20.glShaderSource(id, src)
            GLES20.glCompileShader(id)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(id, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw RuntimeException("Shader error: " + GLES20.glGetShaderInfoLog(id))
            return id
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        return p
    }

    companion object {
        private const val VERT = """
            uniform mat4 uTexMatrix;
            attribute vec4 aPos;
            attribute vec2 aUV;
            varying vec2 vUV;
            void main() {
                gl_Position = aPos;
                vUV = (uTexMatrix * vec4(aUV, 0.0, 1.0)).xy;
            }
        """

        // Catmull-Rom bicubic (9 bilinear taps) + local-contrast-limited sharpening.
        private const val FRAG = """
            #extension GL_OES_EGL_image_external : require
            precision highp float;
            uniform samplerExternalOES uTex;
            uniform vec2 uTexSize;
            uniform vec2 uPx;
            uniform float uSharp;
            varying vec2 vUV;

            vec3 tap(vec2 p) { return texture2D(uTex, p).rgb; }

            vec3 catmull(vec2 uv) {
                vec2 sp = uv * uTexSize;
                vec2 t1 = floor(sp - 0.5) + 0.5;
                vec2 f = sp - t1;
                vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
                vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
                vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
                vec2 w3 = f * f * (-0.5 + 0.5 * f);
                vec2 w12 = w1 + w2;
                vec2 t12 = (t1 + w2 / w12) / uTexSize;
                vec2 t0 = (t1 - 1.0) / uTexSize;
                vec2 t3 = (t1 + 2.0) / uTexSize;
                vec3 r = vec3(0.0);
                r += tap(vec2(t0.x,  t0.y))  * (w0.x  * w0.y);
                r += tap(vec2(t12.x, t0.y))  * (w12.x * w0.y);
                r += tap(vec2(t3.x,  t0.y))  * (w3.x  * w0.y);
                r += tap(vec2(t0.x,  t12.y)) * (w0.x  * w12.y);
                r += tap(vec2(t12.x, t12.y)) * (w12.x * w12.y);
                r += tap(vec2(t3.x,  t12.y)) * (w3.x  * w12.y);
                r += tap(vec2(t0.x,  t3.y))  * (w0.x  * w3.y);
                r += tap(vec2(t12.x, t3.y))  * (w12.x * w3.y);
                r += tap(vec2(t3.x,  t3.y))  * (w3.x  * w3.y);
                return r;
            }

            void main() {
                vec3 c = catmull(vUV);
                vec3 n = tap(vUV + vec2(0.0,  uPx.y));
                vec3 s = tap(vUV + vec2(0.0, -uPx.y));
                vec3 e = tap(vUV + vec2( uPx.x, 0.0));
                vec3 w = tap(vUV + vec2(-uPx.x, 0.0));
                vec3 mn = min(min(min(n, s), min(e, w)), c);
                vec3 mx = max(max(max(n, s), max(e, w)), c);
                vec3 avg = (n + s + e + w) * 0.25;
                vec3 res = c + (c - avg) * uSharp;
                res = clamp(res, mn - 0.04, mx + 0.04);
                gl_FragColor = vec4(clamp(res, 0.0, 1.0), 1.0);
            }
        """
    }
}
