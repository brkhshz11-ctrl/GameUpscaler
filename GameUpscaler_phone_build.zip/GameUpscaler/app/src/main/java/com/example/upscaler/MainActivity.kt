package com.example.upscaler

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {

    private val reqCapture = 100
    private lateinit var prefs: SharedPreferences
    private lateinit var scaleGroup: RadioGroup
    private lateinit var sharpBar: SeekBar

    private val scales = listOf("50%" to 0.5f, "67%" to 0.67f, "75%" to 0.75f, "100%" to 1.0f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun label(s: String, size: Float = 16f) = TextView(this).apply {
            text = s; textSize = size; setPadding(0, pad / 2, 0, pad / 2)
        }

        root.addView(label("Game Upscaler", 26f))
        root.addView(label(
            "1) شغّل اللعبة أولًا واتركها في الخلفية.\n" +
            "2) اضغط «تشغيل» هنا، ثم اختر «تطبيق واحد» (A single app) واختر اللعبة.\n" +
            "3) افتح اللعبة. للإيقاف استخدم زر «إيقاف» في الإشعار."
        ))

        root.addView(label("حجم الالتقاط (يقلل الدقة قبل التكبير)"))
        scaleGroup = RadioGroup(this)
        scales.forEachIndexed { i, (name, _) ->
            scaleGroup.addView(RadioButton(this).apply { id = i + 1; text = name })
        }
        scaleGroup.check(prefs.getInt("scaleIdx", 1) + 1)
        root.addView(scaleGroup)

        root.addView(label("قوة الحدة"))
        sharpBar = SeekBar(this).apply { max = 100; progress = prefs.getInt("sharp", 60) }
        root.addView(sharpBar)

        root.addView(Button(this).apply { text = "تشغيل"; setOnClickListener { start() } })
        root.addView(Button(this).apply {
            text = "إيقاف"
            setOnClickListener { stopService(Intent(this@MainActivity, UpscaleService::class.java)) }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات الأخرى» ثم ارجع", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        prefs.edit()
            .putInt("scaleIdx", scaleGroup.checkedRadioButtonId - 1)
            .putInt("sharp", sharpBar.progress)
            .apply()
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqCapture || resultCode != RESULT_OK || data == null) return
        val scale = scales[(scaleGroup.checkedRadioButtonId - 1).coerceIn(0, scales.lastIndex)].second
        val sharp = sharpBar.progress / 100f * 1.5f
        startForegroundService(
            Intent(this, UpscaleService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
                .putExtra("scale", scale)
                .putExtra("sharp", sharp)
        )
        moveTaskToBack(true)
    }
}
